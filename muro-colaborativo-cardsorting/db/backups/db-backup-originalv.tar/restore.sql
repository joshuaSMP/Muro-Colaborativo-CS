--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 9.6.11
-- Dumped by pg_dump version 9.6.12

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE ONLY public.shared_object DROP CONSTRAINT shared_object_activity_id_fkey;
ALTER TABLE ONLY public.activity DROP CONSTRAINT session_owner_fkey;
ALTER TABLE ONLY public.action DROP CONSTRAINT action_activity_id_fkey;
ALTER TABLE ONLY public."user" DROP CONSTRAINT user_pkey;
ALTER TABLE ONLY public."user" DROP CONSTRAINT user_email_key;
ALTER TABLE ONLY public.activity DROP CONSTRAINT session_pkey;
ALTER TABLE ONLY public.shared_object DROP CONSTRAINT public_object_pkey;
ALTER TABLE ONLY public.activity DROP CONSTRAINT activity_pin_key;
ALTER TABLE ONLY public.action DROP CONSTRAINT action_pkey;
DROP TABLE public."user";
DROP TABLE public.shared_object;
DROP TABLE public.activity;
DROP TABLE public.action;
DROP EXTENSION "uuid-ossp";
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: adef
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO adef;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: adef
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: action; Type: TABLE; Schema: public; Owner: adef
--

CREATE TABLE public.action (
    user_id text NOT NULL,
    shared_object_id uuid NOT NULL,
    x_coordinate numeric,
    y_coordinate numeric,
    creation_date timestamp without time zone DEFAULT now() NOT NULL,
    activity_id uuid NOT NULL,
    id uuid DEFAULT public.uuid_generate_v1() NOT NULL,
    type text NOT NULL,
    pin bigint
);


ALTER TABLE public.action OWNER TO adef;

--
-- Name: activity; Type: TABLE; Schema: public; Owner: adef
--

CREATE TABLE public.activity (
    name character varying(100),
    pin integer NOT NULL,
    background_image text NOT NULL,
    id uuid DEFAULT public.uuid_generate_v1() NOT NULL,
    owner_id uuid,
    is_active boolean DEFAULT true NOT NULL,
    is_deleted boolean DEFAULT false NOT NULL,
    edited_date timestamp with time zone,
    creation_date timestamp with time zone DEFAULT now(),
    available_seats smallint DEFAULT 20,
    max_number_users smallint DEFAULT 20,
    users_data json,
    is_paused boolean DEFAULT false,
    activation_date timestamp with time zone,
    activation_time bigint
);


ALTER TABLE public.activity OWNER TO adef;

--
-- Name: shared_object; Type: TABLE; Schema: public; Owner: adef
--

CREATE TABLE public.shared_object (
    id uuid DEFAULT public.uuid_generate_v1() NOT NULL,
    room integer,
    percentage_x numeric NOT NULL,
    percentage_y numeric NOT NULL,
    type character varying(50) NOT NULL,
    cursor integer,
    is_deleted boolean DEFAULT false NOT NULL,
    deleted_date date,
    last_moved_date timestamp with time zone,
    last_edited_date timestamp with time zone,
    return_private_zone_date timestamp with time zone,
    moved_times integer DEFAULT 0,
    edited_times integer DEFAULT 0,
    shared_times integer DEFAULT 0,
    text text,
    activity_id uuid,
    creation_date timestamp with time zone DEFAULT now() NOT NULL,
    shared_date timestamp with time zone,
    owners text[],
    public_id text,
    image_path text
);


ALTER TABLE public.shared_object OWNER TO adef;

--
-- Name: user; Type: TABLE; Schema: public; Owner: adef
--

CREATE TABLE public."user" (
    id uuid DEFAULT public.uuid_generate_v1() NOT NULL,
    name text,
    email text NOT NULL,
    username text,
    pw character varying(100),
    role character varying(50),
    is_deleted boolean DEFAULT false NOT NULL
);


ALTER TABLE public."user" OWNER TO adef;

--
-- Data for Name: action; Type: TABLE DATA; Schema: public; Owner: adef
--

COPY public.action (user_id, shared_object_id, x_coordinate, y_coordinate, creation_date, activity_id, id, type, pin) FROM stdin;
\.
COPY public.action (user_id, shared_object_id, x_coordinate, y_coordinate, creation_date, activity_id, id, type, pin) FROM '$$PATH$$/3097.dat';

--
-- Data for Name: activity; Type: TABLE DATA; Schema: public; Owner: adef
--

COPY public.activity (name, pin, background_image, id, owner_id, is_active, is_deleted, edited_date, creation_date, available_seats, max_number_users, users_data, is_paused, activation_date, activation_time) FROM stdin;
\.
COPY public.activity (name, pin, background_image, id, owner_id, is_active, is_deleted, edited_date, creation_date, available_seats, max_number_users, users_data, is_paused, activation_date, activation_time) FROM '$$PATH$$/3095.dat';

--
-- Data for Name: shared_object; Type: TABLE DATA; Schema: public; Owner: adef
--

COPY public.shared_object (id, room, percentage_x, percentage_y, type, cursor, is_deleted, deleted_date, last_moved_date, last_edited_date, return_private_zone_date, moved_times, edited_times, shared_times, text, activity_id, creation_date, shared_date, owners, public_id, image_path) FROM stdin;
\.
COPY public.shared_object (id, room, percentage_x, percentage_y, type, cursor, is_deleted, deleted_date, last_moved_date, last_edited_date, return_private_zone_date, moved_times, edited_times, shared_times, text, activity_id, creation_date, shared_date, owners, public_id, image_path) FROM '$$PATH$$/3096.dat';

--
-- Data for Name: user; Type: TABLE DATA; Schema: public; Owner: adef
--

COPY public."user" (id, name, email, username, pw, role, is_deleted) FROM stdin;
\.
COPY public."user" (id, name, email, username, pw, role, is_deleted) FROM '$$PATH$$/3094.dat';

--
-- Name: action action_pkey; Type: CONSTRAINT; Schema: public; Owner: adef
--

ALTER TABLE ONLY public.action
    ADD CONSTRAINT action_pkey PRIMARY KEY (id);


--
-- Name: activity activity_pin_key; Type: CONSTRAINT; Schema: public; Owner: adef
--

ALTER TABLE ONLY public.activity
    ADD CONSTRAINT activity_pin_key UNIQUE (pin);


--
-- Name: shared_object public_object_pkey; Type: CONSTRAINT; Schema: public; Owner: adef
--

ALTER TABLE ONLY public.shared_object
    ADD CONSTRAINT public_object_pkey PRIMARY KEY (id);


--
-- Name: activity session_pkey; Type: CONSTRAINT; Schema: public; Owner: adef
--

ALTER TABLE ONLY public.activity
    ADD CONSTRAINT session_pkey PRIMARY KEY (id);


--
-- Name: user user_email_key; Type: CONSTRAINT; Schema: public; Owner: adef
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT user_email_key UNIQUE (email);


--
-- Name: user user_pkey; Type: CONSTRAINT; Schema: public; Owner: adef
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT user_pkey PRIMARY KEY (id);


--
-- Name: action action_activity_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: adef
--

ALTER TABLE ONLY public.action
    ADD CONSTRAINT action_activity_id_fkey FOREIGN KEY (activity_id) REFERENCES public.activity(id);


--
-- Name: activity session_owner_fkey; Type: FK CONSTRAINT; Schema: public; Owner: adef
--

ALTER TABLE ONLY public.activity
    ADD CONSTRAINT session_owner_fkey FOREIGN KEY (owner_id) REFERENCES public."user"(id);


--
-- Name: shared_object shared_object_activity_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: adef
--

ALTER TABLE ONLY public.shared_object
    ADD CONSTRAINT shared_object_activity_id_fkey FOREIGN KEY (activity_id) REFERENCES public.activity(id);


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: adef
--

REVOKE ALL ON SCHEMA public FROM rdsadmin;
REVOKE ALL ON SCHEMA public FROM PUBLIC;
GRANT ALL ON SCHEMA public TO adef;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

